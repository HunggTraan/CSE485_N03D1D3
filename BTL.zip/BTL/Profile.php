<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="Css/Profile.css">
	<link rel="stylesheet" type="text/css" href="Css/bootstrap.min.css">
</head>
<body>
		<!-- giới thiệu bản thân này -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-6 introduce">
				<br>
				<h3>
					h3. Lorem ipsum dolor sit amet.
				</h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>


				<!-- Trình chiếu ảnh này -->
				<div class="row" style="margin-top: 50px;">
					<div class="col-md-6">
						<div class="button_cont" align="center"><a class="btnbtn" href="">Trò chuyện ngay</a></div>
					</div>
					<div class="col-md-6">
						<div class="button_cont" align="center"><a class="btnbtn" href="">Tìm người khác</a></div>
					</div>
				</div>
			</div>
			<div class="wrapper">
				<div class="gallery">
					<ul>
						<li><div style="background-image: url(<?php echo $article->getImage() ?>);"></div></li>
						<li><div style="background-image: url(<?php echo $article->getImage() ?>);"></div></li>
						<li><div style="background-image: url(<?php echo $article->getImage() ?>);"></div></li>
						<li><div style="background-image: url(<?php echo $article->getImage() ?>);"></div></li>
						<li><div style="background-image: url(<?php echo $article->getImage() ?>);"></div></li>
						<li><div style="background-image: url(<?php echo $article->getImage() ?>);"></div></li>
					</ul>
				</div>
			</div>


			<script src="js/jquery.min.js"></script>
			<script src="js/bootstrap.min.js"></script>
			<script src="js/scripts.js"></script>
			<script src="js/profile.js"></script>
		</body>
		</html>