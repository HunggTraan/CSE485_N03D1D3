var modal = document.getElementById('modal-wrapper-1');
window.onclick = function(event) {
	if (event.target == modal) {
		modal.style.display = "none";
	}
}

var modal = document.getElementById('modal-wrapper-2');
window.onclick = function(event) {
	if (event.target == modal) {
		modal.style.display = "none";
	}
}
