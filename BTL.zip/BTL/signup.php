
<?php
	session_start();
	$db = mysqli_connect("localhost","root","","soulmate");
	if (isset($_POST['signup_btn'])) {
		$Username = $_POST['Username'];
		$Password = $_POST['Password'];
		$Password_Confirm = $_POST['Password_Confirm'];
		$Email = $_POST['Email'];
		$Age = $_POST['Age'];
		$Address = $_POST['Address'];

		if ($Password == $Password_Confirm) {
			$Password = md5($Password);
			$sql = "INSERT INTO account(Username, Password, Email, Age, Address) values ('$Username', '$Password', '$Email', '$Age', '$Address')";
			mysqli_query($db,$sql);
			$_SESSION['Message'] = "Logged In";
			$_SESSION['Username'] = $Username;
			header("location: homepage.php");
		}
	} else {
		$_SESSION['Message'] = "Password mismatch";
	}

?> 


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="Css/signup.css">
	<link rel="stylesheet" type="text/css" href="Css/style.css">
	<title> Đăng ký </title>
</head>
<body class="main">
	<div class="Container pad-top pad-bot">
		<div class="Login-Form">
			<div class="table table2">
				<div class="left-table">
				</div>
				<div class="right-table">
					<h1>Register</h1>
					<form method="POST" action="signup.php">
						<div class="input-form">
							<label for="Username"><b>Username: </b></label>
							<div>
								<input type="Text" placeholder="Enter Username" name="Username" required>
							</div>
						</div>
						<div class="input-form">
							<label for="Password"><b>Password: </b></label>
							<div>
								<input type="Password" placeholder="Enter Password" name="Password" required>
							</div>
						</div>
						<div class="input-form">
							<label for="Password_Confirm"><b>Confirm Password: </b></label>
							<div>
								<input type="Password" placeholder="Enter Password Again " name="Password_Confirm" required>
							</div>	
						</div>
						<div class="input-form">
							<label for="Email"><b>Email: </b></label>
							<div>
								<input type="Text" placeholder="Your email" name="Email">
							</div>
						</div>
						<div class="input-form">
							<label for="Age"><b>Age: </b></label>
							<div>
								<input type="Text" placeholder="Yoooo" name="Age">
							</div>
						</div>
						<div class="input-form">
							<label for="Address"><b>Address: </b></label>
							<div>
								<input type="Text" placeholder="Your Address" name="Address">
							</div>
						</div>
						<div class="input-form">
							<label for="Gender"><b>Gender: </b></label>
							<input type="Radio" name="Gender">Male
							<input type="Radio" name="Gender">Female
						</div>
						<div class="clearfix">
							<a href="index.php">Hủy bỏ</a>
							<button type="Submit" class="signup_btn" name="signup_btn">Đăng ký</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</body>
</html>