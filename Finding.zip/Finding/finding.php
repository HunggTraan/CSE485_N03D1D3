<?php
	session_start();
	$Username = $_SESSION['Username'];
	$db = mysqli_connect("localhost","root","","soulmate");
	$records = mysqli_query($db,"");
	$rows = mysqli_num_rows($records);
	if ($rows == 1) {
		$field = mysqli_fetch_assoc($records);
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="finding.css">
</head>
<body>
	<div class="slider">
		<div class="slider-wrapper flex">
			<div class="slide flex">
				<div class="slide-image slider-link prev"><img src="" name="" style="<!-- echo ảnh ở đây -->"></div>
				<div class="slide-content">
					<div class="slide-text"><?php echo $field['']; ?></div> <!-- echo text -->
				</div>	
			</div>
			<div class="slide flex">
				<div class="slide-image slider-link next"><img src="" name="" style="<!-- echo ảnh ở đây -->" ></div>
				<div class="slide-content">
					<div class="slide-text"><?php echo $field['']; ?></div> <!-- echo text -->
				</div>	
			</div>	
			<div class="slide flex">
				<div class="slide-image slider-link next"><img src=""  name="" style="<!-- echo ảnh ở đây -->"></div>
				<div class="slide-content">
					<div class="slide-text"><?php echo $field['']; ?></div> <!-- echo text -->
				</div>	
			</div>
		</div>
		<div class="button-align">
			<div class="button_cont"><a class="btnbtn" href="">Trò chuyện ngay</a></div>
			<div class="button_cont"><a class="btnbtn" href="">Tìm người khác</a></div>
		</div>	
		<div class="arrows">
			<a href="#" title="Previous" class="arrow slider-link prev"></a>
			<a href="#" title="Next" class="arrow slider-link next"></a>
		</div>
	</div>


	<script src='https://code.jquery.com/jquery-2.2.4.min.js'></script>
	<script src='https://cdnjs.cloudflare.com/ajax/libs/gsap/1.19.1/TweenMax.min.js'></script>

	<script type="text/javascript" src="js/finding.js"></script>
</body>
</html>